# vdw-surfgen

`vdw-surfgen` is a Python CLI tool to generate points on the van der Waals (VDW) surface of a molecule using its XYZ geometry file.

Surface points are generated at a scaled VDW radius and can be used for visualization, machine learning, or molecular modeling.

It is built on logic by Robert T. McGibbon's [pyvdwsurface](https://github.com/rmcgibbo/pyvdwsurface).

## 🔧 Features

- Read atomic coordinates from `.xyz` files
- Compute VDW surface points using Fibonacci sphere sampling
- Set surface density (points per Å²)
- Save results as:
  - `.txt` coordinate file
  - `.xyz` pseudo-atom file
  - `.png` 3D scatter plot
- Command-line interface (CLI) with full control

## 🚀 Installation

```bash

pip install vdw-surfgen

```

## 🔨Usage

```bash

vsg molecule.xyz --scale 1 --density 2.0 --save_txt --save_xyz --save_img

```

[soajagbe](https://github.com/sajagbe).

